"use client";
import { useState, useEffect, useRef } from "react";
import Link from "next/link";

const CHANNELS = [
  { name: "House Vibes",        genre: "Deep · Tech · 128 BPM",      tint: "rgba(180,120,20,0.06)" },
  { name: "Techno Underground", genre: "Dark · Industrial · 140 BPM", tint: "rgba(20,40,80,0.08)"  },
  { name: "R&B & Soul",         genre: "Neo Soul · Funk · 90 BPM",    tint: "rgba(60,20,60,0.08)"  },
];

const PILL_BARS = [3, 7, 11, 7, 3];

export default function RadioStrip() {
  const [isOpen,        setIsOpen]        = useState(false);
  const [isPlaying,     setIsPlaying]     = useState(false);
  const [activeChannel, setActiveChannel] = useState(0);
  const [volume,        setVolume]        = useState(75);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onMouseDown(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", onMouseDown);
    return () => document.removeEventListener("mousedown", onMouseDown);
  }, []);

  const ch = CHANNELS[activeChannel];

  return (
    <div
      ref={ref}
      className="radio-strip-desktop"
      style={{ position: "fixed", bottom: "24px", right: "24px", zIndex: 500 }}
    >
      {/* ── Expanded panel ──────────────────────────────── */}
      {isOpen && (
        <div style={{
          position: "absolute", bottom: "52px", right: 0,
          width: "260px",
          background: "#0e0e1c",
          border: "1px solid rgba(232,160,32,0.18)",
          borderRadius: "12px",
          overflow: "hidden",
          boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
          zIndex: 499,
          animation: "panelIn 0.3s cubic-bezier(0.4,0,0.2,1) both",
          transformOrigin: "bottom right",
        }}>

          {/* Header */}
          <div style={{
            padding: "12px 16px",
            borderBottom: "1px solid rgba(255,255,255,0.05)",
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "8px", letterSpacing: "0.2em", textTransform: "uppercase", color: "#71717A" }}>
              Nightwaves
            </span>
            <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
              <div style={{ width: "5px", height: "5px", borderRadius: "50%", background: "#E8A020" }} />
              <span style={{ fontFamily: "var(--font-mono)", fontSize: "8px", letterSpacing: "0.2em", textTransform: "uppercase", color: "#E8A020" }}>
                Live
              </span>
            </div>
          </div>

          {/* Volume */}
          <div style={{
            padding: "12px 16px",
            borderBottom: "1px solid rgba(255,255,255,0.05)",
            display: "flex", alignItems: "center", gap: "10px",
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#71717A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
              {volume > 0  && <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>}
              {volume > 50 && <path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>}
            </svg>
            <input
              type="range"
              min={0} max={100}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="volume-slider"
              style={{
                flex: 1,
                background: `linear-gradient(to right, #E8A020 ${volume}%, rgba(255,255,255,0.1) ${volume}%)`,
              }}
            />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "8px", color: "#71717A", minWidth: "28px", textAlign: "right" }}>
              {volume}%
            </span>
          </div>

          {/* Channel rows */}
          {CHANNELS.map((channel, i) => {
            const active = activeChannel === i;
            return (
              <button
                key={channel.name}
                onClick={() => { setActiveChannel(i); setIsPlaying(true); setIsOpen(false); }}
                style={{
                  display: "flex", alignItems: "center",
                  width: "100%", padding: "10px 16px", gap: "12px",
                  background: active ? "rgba(232,160,32,0.05)" : "transparent",
                  border: "none",
                  borderLeft: `2px solid ${active ? "#E8A020" : "transparent"}`,
                  borderBottom: "1px solid rgba(255,255,255,0.03)",
                  borderRadius: "4px",
                  cursor: "pointer", outline: "none", textAlign: "left",
                  transition: "all 0.2s",
                }}
                onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = "rgba(255,255,255,0.02)"; }}
                onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = active ? "rgba(232,160,32,0.05)" : "transparent"; }}
              >
                {/* Play/pause indicator */}
                <div style={{
                  width: "20px", height: "20px", flexShrink: 0,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  border: `1px solid ${active ? "rgba(232,160,32,0.5)" : "rgba(255,255,255,0.1)"}`,
                }}>
                  {active && isPlaying ? (
                    <div style={{ display: "flex", gap: "2px", alignItems: "center" }}>
                      <div style={{ width: "2px", height: "7px", background: "#E8A020" }} />
                      <div style={{ width: "2px", height: "7px", background: "#E8A020" }} />
                    </div>
                  ) : (
                    <div style={{
                      width: 0, height: 0,
                      borderTop: "4px solid transparent",
                      borderBottom: "4px solid transparent",
                      borderLeft: `6px solid ${active ? "#E8A020" : "#555"}`,
                      marginLeft: "1px",
                    }} />
                  )}
                </div>

                {/* Channel info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: "12px", color: active ? "#F4F4F5" : "#71717A", lineHeight: 1.3, marginBottom: "2px" }}>
                    {channel.name}
                  </div>
                  <div style={{ fontFamily: "var(--font-mono)", fontSize: "8px", letterSpacing: "0.06em", textTransform: "uppercase", color: "#444" }}>
                    {channel.genre}
                  </div>
                </div>

                {/* Live wave bars */}
                {active && isPlaying && (
                  <div style={{ display: "flex", alignItems: "center", gap: "2px" }}>
                    {[7, 11, 7, 11].map((h, idx) => (
                      <div key={idx} className="wave-bar" style={{ height: `${h}px` }} />
                    ))}
                  </div>
                )}
              </button>
            );
          })}

          {/* Footer */}
          <Link
            href="/nightwaves"
            onClick={() => setIsOpen(false)}
            style={{
              display: "block", padding: "10px 16px",
              fontFamily: "var(--font-mono)", fontSize: "8px",
              letterSpacing: "0.14em", textTransform: "uppercase",
              color: "#71717A", textDecoration: "none",
              borderTop: "1px solid rgba(255,255,255,0.04)",
              textAlign: "center",
              transition: "color 0.2s",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.color = "#A1A1AA"; }}
            onMouseLeave={(e) => { e.currentTarget.style.color = "#71717A"; }}
          >
            Full Nightwaves player →
          </Link>
        </div>
      )}

      {/* ── Collapsed pill ──────────────────────────────── */}
      <div
        onClick={() => setIsOpen((o) => !o)}
        style={{
          position: "relative",
          height: "44px",
          width: "200px",
          background: "#0e0e1c",
          border: `1px solid rgba(232,160,32,${isPlaying ? "0.5" : "0.22"})`,
          borderRadius: "9999px",
          display: "flex", alignItems: "center",
          padding: "0 8px 0 14px",
          gap: "10px",
          boxShadow: "0 4px 24px rgba(0,0,0,0.5)",
          cursor: "pointer",
          transition: "all 0.3s",
          overflow: "hidden",
        }}
      >
        {/* Channel tint overlay */}
        <div style={{ position: "absolute", inset: 0, background: ch.tint, pointerEvents: "none" }} />

        {/* Waveform bars */}
        <div style={{ display: "flex", alignItems: "center", gap: "1.5px", flexShrink: 0, position: "relative" }}>
          {PILL_BARS.map((h, i) =>
            isPlaying ? (
              <div key={i} className="wave-bar" style={{ height: `${h}px` }} />
            ) : (
              <div key={i} style={{ width: "2px", height: `${h}px`, background: "rgba(232,160,32,0.25)", borderRadius: "1px" }} />
            )
          )}
        </div>

        {/* Label */}
        <span style={{
          flex: 1,
          fontFamily: "var(--font-mono)", fontSize: "9px",
          letterSpacing: "0.14em", textTransform: "uppercase",
          color: isPlaying ? "#D4D4D8" : "#71717A",
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
          position: "relative",
        }}>
          {isPlaying ? ch.name : "Nightwaves"}
        </span>

        {/* Toggle button */}
        <button
          onClick={(e) => { e.stopPropagation(); setIsOpen((o) => !o); }}
          style={{
            width: "32px", height: "32px", borderRadius: "50%",
            display: "flex", alignItems: "center", justifyContent: "center",
            background: "rgba(232,160,32,0.08)",
            border: "1px solid rgba(232,160,32,0.25)",
            color: "#E8A020", fontSize: "18px", fontWeight: 300,
            cursor: "pointer", flexShrink: 0, lineHeight: 1,
            position: "relative",
          }}
        >
          {isOpen ? "×" : "+"}
        </button>
      </div>
    </div>
  );
}
