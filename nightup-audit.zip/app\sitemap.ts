import type { MetadataRoute } from "next";
import { events, articles } from "./lib/data";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://nightup.gr";
  const now = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: base, lastModified: now, changeFrequency: "daily", priority: 1 },
    { url: `${base}/events`, lastModified: now, changeFrequency: "daily", priority: 0.9 },
    { url: `${base}/events/all`, lastModified: now, changeFrequency: "daily", priority: 0.8 },
    { url: `${base}/magazine`, lastModified: now, changeFrequency: "weekly", priority: 0.8 },
    { url: `${base}/party`, lastModified: now, changeFrequency: "weekly", priority: 0.8 },
    { url: `${base}/nightwaves`, lastModified: now, changeFrequency: "weekly", priority: 0.7 },
    { url: `${base}/about`, lastModified: now, changeFrequency: "monthly", priority: 0.5 },
  ];

  const eventRoutes: MetadataRoute.Sitemap = events.map((e) => ({
    url: `${base}/events/${e.id}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: 0.7,
  }));

  const articleRoutes: MetadataRoute.Sitemap = articles.map((a) => ({
    url: `${base}/magazine/${a.id}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.6,
  }));

  return [...staticRoutes, ...eventRoutes, ...articleRoutes];
}
